package com.example.focus;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper manages all database operations for the Focus app.
 * It handles two tables: one for user accounts and one for weight entries.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "FocusApp.db";
    private static final int DATABASE_VERSION = 1;

    // Users table - stores login credentials
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_PHONE_NUMBER = "phone_number";

    // Weight entries table - stores daily weight records
    private static final String TABLE_WEIGHT = "weight_entries";
    private static final String COLUMN_WEIGHT_ID = "weight_id";
    private static final String COLUMN_WEIGHT_USER_ID = "user_id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    /**
     * Constructor for DatabaseHelper
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is first created.
     * Creates the users and weight_entries tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COLUMN_PASSWORD + " TEXT NOT NULL, " +
                COLUMN_GOAL_WEIGHT + " REAL DEFAULT 0, " +
                COLUMN_PHONE_NUMBER + " TEXT)";
        db.execSQL(createUsersTable);

        // Create weight entries table
        String createWeightTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_WEIGHT_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_DATE + " TEXT NOT NULL, " +
                COLUMN_WEIGHT + " REAL NOT NULL, " +
                "FOREIGN KEY(" + COLUMN_WEIGHT_USER_ID + ") REFERENCES " +
                TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createWeightTable);
    }

    /**
     * Called when the database needs to be upgraded.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ==================== USER OPERATIONS ====================

    /**
     * Adds a new user to the database.
     * Returns true if successful, false if username already exists.
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        // Insert returns -1 if there was an error (like duplicate username)
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /**
     * Checks if username and password match a record in the database.
     * Returns the user ID if valid, -1 if not found.
     */
    public int checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS +
                " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }
        cursor.close();
        return userId;
    }

    /**
     * Updates the user's goal weight.
     */
    public boolean updateGoalWeight(int userId, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        int rowsAffected = db.update(TABLE_USERS, values,
                COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        return rowsAffected > 0;
    }

    /**
     * Updates the user's phone number for SMS notifications.
     */
    public boolean updatePhoneNumber(int userId, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);

        int rowsAffected = db.update(TABLE_USERS, values,
                COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        return rowsAffected > 0;
    }

    /**
     * Gets the user's goal weight.
     */
    public double getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_USERS +
                " WHERE " + COLUMN_USER_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        double goalWeight = 0;
        if (cursor.moveToFirst()) {
            goalWeight = cursor.getDouble(0);
        }
        cursor.close();
        return goalWeight;
    }

    /**
     * Gets the user's phone number.
     */
    public String getPhoneNumber(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_PHONE_NUMBER + " FROM " + TABLE_USERS +
                " WHERE " + COLUMN_USER_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        String phoneNumber = null;
        if (cursor.moveToFirst()) {
            phoneNumber = cursor.getString(0);
        }
        cursor.close();
        return phoneNumber;
    }

    // ==================== WEIGHT ENTRY OPERATIONS ====================

    /**
     * Adds a new weight entry for a user.
     * Returns true if successful.
     */
    public boolean addWeightEntry(int userId, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_USER_ID, userId);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHT, null, values);
        return result != -1;
    }

    /**
     * Gets all weight entries for a user, ordered by date descending.
     * Returns a Cursor with columns: weight_id, date, weight
     */
    public Cursor getAllWeightEntries(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_WEIGHT_ID + ", " + COLUMN_DATE + ", " +
                COLUMN_WEIGHT + " FROM " + TABLE_WEIGHT +
                " WHERE " + COLUMN_WEIGHT_USER_ID + " = ?" +
                " ORDER BY " + COLUMN_WEIGHT_ID + " DESC";
        return db.rawQuery(query, new String[]{String.valueOf(userId)});
    }

    /**
     * Updates an existing weight entry.
     * Returns true if successful.
     */
    public boolean updateWeightEntry(int weightId, String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        int rowsAffected = db.update(TABLE_WEIGHT, values,
                COLUMN_WEIGHT_ID + " = ?", new String[]{String.valueOf(weightId)});
        return rowsAffected > 0;
    }

    /**
     * Deletes a weight entry.
     * Returns true if successful.
     */
    public boolean deleteWeightEntry(int weightId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_WEIGHT,
                COLUMN_WEIGHT_ID + " = ?", new String[]{String.valueOf(weightId)});
        return rowsAffected > 0;
    }
}
