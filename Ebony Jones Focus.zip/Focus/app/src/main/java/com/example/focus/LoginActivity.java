package com.example.focus;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity handles user authentication.
 * Users can either log in with existing credentials or create a new account.
 * Successful login saves the user ID and redirects to the weight tracking screen.
 */
public class LoginActivity extends AppCompatActivity {

    // UI elements
    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnCreateAccount;

    // Database helper for user operations
    private DatabaseHelper databaseHelper;

    // SharedPreferences to store logged-in user info
    private static final String PREFS_NAME = "FocusAppPrefs";
    private static final String KEY_USER_ID = "user_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Connect UI elements to their XML counterparts
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // Set up login button click listener
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });

        // Set up create account button click listener
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleCreateAccount();
            }
        });
    }

    /**
     * Handles the login process.
     * Validates input, checks credentials against database,
     * and redirects to weight tracking screen if successful.
     */
    private void handleLogin() {
        // Get user input
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Validate that fields are not empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Check credentials against database
        int userId = databaseHelper.checkUser(username, password);

        if (userId != -1) {
            // Login successful - save user ID to SharedPreferences
            saveUserId(userId);

            // Show success message
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

            // Navigate to weight tracking screen
            Intent intent = new Intent(LoginActivity.this, WeightDataActivity.class);
            startActivity(intent);
            finish(); // Close login screen so user can't go back to it
        } else {
            // Login failed - show error message
            Toast.makeText(this, "Invalid username or password",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles creating a new user account.
     * Validates input and adds new user to database.
     */
    private void handleCreateAccount() {
        // Get user input
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Validate that fields are not empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter both username and password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate password length for basic security
        if (password.length() < 4) {
            Toast.makeText(this, "Password must be at least 4 characters",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Try to add user to database
        boolean success = databaseHelper.addUser(username, password);

        if (success) {
            // Account created successfully
            Toast.makeText(this, "Account created! You can now log in.",
                    Toast.LENGTH_SHORT).show();

            // Clear the password field for security
            etPassword.setText("");
        } else {
            // Username already exists
            Toast.makeText(this, "Username already exists. Please choose another.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Saves the user ID to SharedPreferences for persistent login state.
     */
    private void saveUserId(int userId) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_USER_ID, userId);
        editor.apply();
    }

    /**
     * Static method to get the logged-in user ID from any activity.
     * Returns -1 if no user is logged in.
     */
    public static int getUserId(AppCompatActivity activity) {
        SharedPreferences prefs = activity.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getInt(KEY_USER_ID, -1);
    }

    /**
     * Static method to log out the current user.
     */
    public static void logout(AppCompatActivity activity) {
        SharedPreferences prefs = activity.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(KEY_USER_ID);
        editor.apply();
    }
}